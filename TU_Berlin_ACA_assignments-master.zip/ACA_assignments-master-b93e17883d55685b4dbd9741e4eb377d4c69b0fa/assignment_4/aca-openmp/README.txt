
- To compile and run

-> mkdir build
-> cd build
-> cmake ../
-> make

- To run sequential code for example:
-> ./lud_par ../data/1024.dat